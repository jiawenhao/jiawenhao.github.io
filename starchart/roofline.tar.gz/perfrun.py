#!/usr/bin/python
# Read a parameter configuration file and run randomized experiments.
import sys
import os
from subprocess import call
import random
import csv
import time

if len(sys.argv) != 2:
    print "usage: " + sys.argv[0] + " app.config"
    sys.exit(1)

parameters = []
ranges = []
files = []
keywords = []
templates = []
compile = "make clean; make"
profile = ""
run = ""
output = ""
reference = ""
nsample = 1
config = open(sys.argv[1])
for line in config:
    if line.startswith('#'):
        continue
    elif line.startswith('compile'):
        compile = line.split('=')[1].strip()
    elif line.startswith('profile'):
        profile = line.split('=')[1].strip()
    elif line.startswith('run'):
        run = line.split('=')[1].strip()
    elif line.startswith('output'):
        output = line.split('=')[1].strip()
    elif line.startswith('reference'):
        reference = line.split('=')[1].strip()
    elif line.startswith('nsample'):
        nsample = int(line.split('=')[1].strip())
    elif "|" in line:
        tokens = line.split('|')
        assert(len(tokens) >= 5)
        parameters.append(tokens[0].strip())
        files.append([file for file in tokens[1].strip().split(',')])
        keywords.append(tokens[2].strip())
        templates.append(tokens[3].strip())
        values = tokens[4].strip()
        if '-' in values:
            [pmin, pmax] = values.split('-')
            ranges.append(range(int(pmin), int(pmax) + 1))
        elif ':' in values:
            [pmin, pstep, pmax] = values.split(':')
            ranges.append(range(int(pmin), int(pmax) + 1, int(pstep)))
        else:
            ranges.append([int(x) for x in values.split(',')])
config.close()
assert(len(parameters) > 0)
assert(compile != "")
assert(profile != "")
assert(run != "")
if output != "" or reference != "":
    assert(output != "")
    assert(reference != "")

# Print the design space specifications before starting.
print "Executable: " + run
npoint = 1
for i in range(len(parameters)):
    npoint = npoint * len(ranges[i])
if nsample > npoint:
    nsample = npoint
print "Design space size: " + str(npoint) + " points"
print 'Number of samples: ' + str(nsample)
if nsample == npoint:
    print "WARNING: switched to exhaustive experiments due to high sample count"
elif 10 * nsample > npoint:
    print "WARNING: random number generation can be slow for these many samples"

samples = []
# When nsample is large enough, samples are generated exhaustively.
if nsample == npoint:
    for i in range(nsample):
        sample = []
        seed = i
        for j in range(len(parameters)):
            sample.append(str(ranges[j][seed % len(ranges[j])]))
            seed /= len(ranges[j])
        samples.append(sample)
# Else generate samples randomly.
else:
    random.seed()
    for i in range(nsample):
        unique = False
        while not unique:
            sample = []
            for j in range(len(parameters)):
                sample.append(str(random.choice(ranges[j])))
            # if isInvalid(sample):
                # continue
            if not sample in samples:
                unique = True
        samples.append(sample)
file = open("samples.list", 'w')
for p in range(len(parameters)):
    file.write(parameters[p])
    if p < len(parameters) - 1:
        file.write(',')
    else:
        file.write('\n')
file.close()

if profile == "nvidia":
    os.environ["COMPUTE_PROFILE"] = '1'
    os.environ["COMPUTE_PROFILE_CSV"] = '1'
for sample in samples:
    for p in range(len(parameters)):
        for file in files[p]:
            opened = open(file, 'r')
            lines = opened.readlines()
            opened.close()
            keyword = keywords[p]
            template = templates[p]
            for line in lines:
                if keyword in line:
                    lines[lines.index(line)] = template.replace('$', sample[p]) + '\n'
            opened = open(file, 'w')
            for line in lines:
                opened.write(line.rstrip() + '\n')
            opened.close()

    # Compile and run the application.
    if not os.path.exists("logs"):
        os.makedirs("logs")
    csvname = ""
    logname = "logs/"
    for p in range(len(parameters)):
        parameter = parameters[p]
        logname = logname + parameter + '_' + sample[p]
        if p < len(parameters) - 1:
            logname = logname + '_'
        else:
            csvname = logname + ".csv"
            logname = logname + ".log"
    logfile = open(logname, 'w')
    retcodec = call(compile, stdout = logfile, stderr = logfile, shell = True)
    if retcodec == 0:
        print '\nCompiling ' + str(samples.index(sample) + 1) + ' of ' + \
            str(len(samples)) + ' succeeded.'
        print "Pausing for 1 second..."
        time.sleep(1)
        if profile == "nvidia":
            os.environ["COMPUTE_PROFILE_LOG"] = csvname
            retcodee = call(run, stdout = logfile, stderr = logfile, shell = True)
        else:
            retcodee = call(profile + " " + csvname + " " + run, stdout = logfile, stderr = logfile, shell = True)
        if retcodee == 0:
            print "Executing " + str(samples.index(sample) + 1) + " of " + \
                str(len(samples)) + " succeeded."
            print "Pausing for 1 second..."
            time.sleep(1)
            if output != "":
                if call("diff " + output + " " + reference, shell = True) == 0:
                    print "Output passed reference check."
            file = open("samples.list", 'ab')
            writer = csv.writer(file)
            writer.writerow(sample)
            file.close()
        else:
            print "Executing " + str(samples.index(sample) + 1) + " of " + \
                str(len(samples)) + " \033[31mfailed\033[0m."
    else:
        print '\nCompiling ' + str(samples.index(sample) + 1) + ' of ' + \
            str(len(samples)) + " \033[31mfailed\033[0m."
    logfile.close()
