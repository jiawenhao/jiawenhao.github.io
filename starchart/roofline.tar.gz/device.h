#ifdef __cplusplus
#include <cstring>
#else
#include <string.h>
#endif

#define PLATFORM_KEYWORD "NVIDIA"
// #define PLATFORM_KEYWORD "Advanced Micro Devices"
// #define PLATFORM_KEYWORD "Intel"
#define DEVICE_TYPE CL_DEVICE_TYPE_GPU
// #define DEVICE_TYPE CL_DEVICE_TYPE_CPU

#define NITERATION 50
