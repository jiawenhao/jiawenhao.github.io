#! /usr/bin/python
# Collect results from randomized experimental runs.
import sys
import shutil
import os

if len(sys.argv) != 2:
    print "usage: " + sys.argv[0] + " app.config"
    sys.exit(1)

config = open(sys.argv[1])
for line in config:
    if line.startswith('column'):	
        counters = line.split('=')[1].strip().split(',')
        avgoverruns = [int(counter) < 0 for counter in counters]
        columns = [abs(int(counter)) for counter in counters]
    elif line.startswith('kernel'):
        kernels = line.split('=')[1].strip().split(',')
config.close()
device = open("device.h")
for line in device:
    if 'NITERATION' in line:
        niteration = int(line.split()[2].strip())
device.close()
assert(niteration > 0)

samples = open("samples.list", 'r')
header = samples.next().strip()
params = header.split(',')
lines = header
for kernel in kernels:
    for column in columns: 
        lines += "," + kernel + "(" + str(column) + ")"
lines += "\n"
for sample in samples:
    csvname = "logs/"
    values = sample.strip().split(',')
    for i in range(len(params)):
        csvname = csvname + params[i] + "_" + values[i]
        if i < len(params) - 1:
            csvname = csvname + "_"
        else:
            csvname = csvname + ".csv"
    assert(os.path.exists(csvname))
    csvfile = open(csvname)
    counts = [0] * len(kernels) * len(columns)
    totals = [0.0] * len(kernels) * len(columns)
    for line in csvfile:
        if line.startswith('#'):
            continue
        function = line.strip().split(',')[0]
        for k in range(len(kernels)):
            kernel = kernels[k]
            if kernel in function:
                for c in range(len(columns)):
                    column = columns[c]
                    total = float(line.strip().split(',')[column])
                    if total > 0.0:
                        counts[k * len(columns) + c] += 1
                        totals[k * len(columns) + c] += total
    lines += sample.strip()
    for k in range(len(kernels)):
        for c in range(len(columns)):
            if counts[k * len(columns) + c] > 0:
                assert(totals[k * len(columns) + c] > 0.0)
                # The NVIDIA profiler may split a kernel over multiple runs. This affects runtime average but not occupancy.
                if avgoverruns[c]:
                    lines = lines + "," + str(totals[k * len(columns) + c] / counts[k * len(columns) + c])
                else:
                    lines = lines + "," + str(totals[k * len(columns) + c] / niteration)
            else:
                # The AMD profiler logs a line regardless of whether the kernel actually ran.
                lines += ",x"
    lines += "\n"
    csvfile.close()
samples.close()

runtimes = open("samples.csv", 'w')
runtimes.write(lines)
runtimes.close()
