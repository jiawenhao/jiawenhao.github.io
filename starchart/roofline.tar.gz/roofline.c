#include <CL/cl.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "device.h"

#define GLOBAL_WORK_SIZE 1000000
#define GLOBAL_ARRAY_SIZE 10000000
#define LOCAL_ARRAY_SIZE (40 * 1024)
#define REPEAT_COUNT 32

void fatal(cl_int error, int line) {
	printf("Error at line %d: ", line);
	switch(error) {
		case CL_SUCCESS: printf("CL_SUCCESS\n"); break;
		case CL_DEVICE_NOT_FOUND: printf("CL_DEVICE_NOT_FOUND\n"); break;
		case CL_DEVICE_NOT_AVAILABLE: printf("CL_DEVICE_NOT_AVAILABLE\n"); break;
		case CL_COMPILER_NOT_AVAILABLE: printf("CL_COMPILER_NOT_AVAILABLE\n"); break;
		case CL_MEM_OBJECT_ALLOCATION_FAILURE: printf("CL_MEM_OBJECT_ALLOCATION_FAILURE\n"); break;
		case CL_OUT_OF_RESOURCES: printf("CL_OUT_OF_RESOURCES\n"); break;
		case CL_OUT_OF_HOST_MEMORY: printf("CL_OUT_OF_HOST_MEMORY\n"); break;
		case CL_PROFILING_INFO_NOT_AVAILABLE: printf("CL_PROFILING_INFO_NOT_AVAILABLE\n"); break;
		case CL_MEM_COPY_OVERLAP: printf("CL_MEM_COPY_OVERLAP\n"); break;
		case CL_IMAGE_FORMAT_MISMATCH: printf("CL_IMAGE_FORMAT_MISMATCH\n"); break;
		case CL_IMAGE_FORMAT_NOT_SUPPORTED: printf("CL_IMAGE_FORMAT_NOT_SUPPORTED\n"); break;
		case CL_BUILD_PROGRAM_FAILURE: printf("CL_BUILD_PROGRAM_FAILURE\n"); break;
		case CL_MAP_FAILURE: printf("CL_MAP_FAILURE\n"); break;
		case CL_INVALID_VALUE: printf("CL_INVALID_VALUE\n"); break;
		case CL_INVALID_DEVICE_TYPE: printf("CL_INVALID_DEVICE_TYPE\n"); break;
		case CL_INVALID_PLATFORM: printf("CL_INVALID_PLATFORM\n"); break;
		case CL_INVALID_DEVICE: printf("CL_INVALID_DEVICE\n"); break;
		case CL_INVALID_CONTEXT: printf("CL_INVALID_CONTEXT\n"); break;
		case CL_INVALID_QUEUE_PROPERTIES: printf("CL_INVALID_QUEUE_PROPERTIES\n"); break;
		case CL_INVALID_COMMAND_QUEUE: printf("CL_INVALID_COMMAND_QUEUE\n"); break;
		case CL_INVALID_HOST_PTR: printf("CL_INVALID_HOST_PTR\n"); break;
		case CL_INVALID_MEM_OBJECT: printf("CL_INVALID_MEM_OBJECT\n"); break;
		case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR: printf("CL_INVALID_IMAGE_FORMAT_DESCRIPTOR\n"); break;
		case CL_INVALID_IMAGE_SIZE: printf("CL_INVALID_IMAGE_SIZE\n"); break;
		case CL_INVALID_SAMPLER: printf("CL_INVALID_SAMPLER\n"); break;
		case CL_INVALID_BINARY: printf("CL_INVALID_BINARY\n"); break;
		case CL_INVALID_BUILD_OPTIONS: printf("CL_INVALID_BUILD_OPTIONS\n"); break;
		case CL_INVALID_PROGRAM: printf("CL_INVALID_PROGRAM\n"); break;
		case CL_INVALID_PROGRAM_EXECUTABLE: printf("CL_INVALID_PROGRAM_EXECUTABLE\n"); break;
		case CL_INVALID_KERNEL_NAME: printf("CL_INVALID_KERNEL_NAME\n"); break;
		case CL_INVALID_KERNEL_DEFINITION: printf("CL_INVALID_KERNEL_DEFINITION\n"); break;
		case CL_INVALID_KERNEL: printf("CL_INVALID_KERNEL\n"); break;
		case CL_INVALID_ARG_INDEX: printf("CL_INVALID_ARG_INDEX\n"); break;
		case CL_INVALID_ARG_VALUE: printf("CL_INVALID_ARG_VALUE\n"); break;
		case CL_INVALID_ARG_SIZE: printf("CL_INVALID_ARG_SIZE\n"); break;
		case CL_INVALID_KERNEL_ARGS: printf("CL_INVALID_KERNEL_ARGS\n"); break;
		case CL_INVALID_WORK_DIMENSION: printf("CL_INVALID_WORK_DIMENSION\n"); break;
		case CL_INVALID_WORK_GROUP_SIZE: printf("CL_INVALID_WORK_GROUP_SIZE\n"); break;
		case CL_INVALID_WORK_ITEM_SIZE: printf("CL_INVALID_WORK_ITEM_SIZE\n"); break;
		case CL_INVALID_GLOBAL_OFFSET: printf("CL_INVALID_GLOBAL_OFFSET\n"); break;
		case CL_INVALID_EVENT_WAIT_LIST: printf("CL_INVALID_EVENT_WAIT_LIST\n"); break;
		case CL_INVALID_EVENT: printf("CL_INVALID_EVENT\n"); break;
		case CL_INVALID_OPERATION: printf("CL_INVALID_OPERATION\n"); break;
		case CL_INVALID_GL_OBJECT: printf("CL_INVALID_GL_OBJECT\n"); break;
		case CL_INVALID_BUFFER_SIZE: printf("CL_INVALID_BUFFER_SIZE\n"); break;
		case CL_INVALID_MIP_LEVEL: printf("CL_INVALID_MIP_LEVEL\n"); break;
		case CL_INVALID_GLOBAL_WORK_SIZE: printf("CL_INVALID_GLOBAL_WORK_SIZE\n"); break;
		#ifdef CL_VERSION_1_1
		case CL_MISALIGNED_SUB_BUFFER_OFFSET: printf("CL_MISALIGNED_SUB_BUFFER_OFFSET\n"); break;
		case CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST: printf("CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST\n"); break;
		/* case CL_INVALID_PROPERTY: printf("CL_INVALID_PROPERTY\n"); break; */
		#endif
		default: printf("Invalid OpenCL error code\n");
	}
	exit(error);
}

char* load_kernel_source(const char* filename) {
	FILE* file = fopen(filename, "r");
	if (file == NULL) {
		printf("Error opening kernel source file\n");
		exit(1);
	}
	if (fseek(file, 0, SEEK_END)) {
		printf("Error reading kernel source file\n");
		exit(1);
	}
	size_t size = ftell(file);
	char* source = (char*) malloc(size + 1);
	fseek(file, 0, SEEK_SET);
	if (fread(source, 1, size, file) != size) {
		printf("Error reading kernel source file\n");
		exit(1);
	}
	source[size] = '\0';
	return source;
}

int main(int argc, char** argv) {
	int i;
	cl_int error;
	if (argc != 4) {
		printf("Usage: %s block_size comp_comm_ratio coal_degree\n", argv[0]);
		exit(1);
	}
	int bsize = atoi(argv[1]);
	int ratio = atoi(argv[2]);
	int coal = atoi(argv[3]);

	cl_uint nplatform;
	error = clGetPlatformIDs(0, NULL, &nplatform);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	cl_platform_id* platforms = (cl_platform_id*) malloc(sizeof(cl_platform_id) * nplatform);
	error = clGetPlatformIDs(nplatform, platforms, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	cl_platform_id platform = NULL;
	char buffer[100];
	for (i = 0; i < nplatform; i++) {
		error = clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(buffer), buffer, NULL);
		if (error != CL_SUCCESS) fatal(error, __LINE__);
		if (strstr(buffer, PLATFORM_KEYWORD)) {
			platform = platforms[i];
			printf("Platform: %s\n", buffer);
		}
	}
	
	cl_context_properties properties[3] = {CL_CONTEXT_PLATFORM, (cl_context_properties) platform, 0};
	cl_context context = clCreateContextFromType(properties, DEVICE_TYPE, NULL, NULL, &error);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	size_t size;
	error = clGetContextInfo(context, CL_CONTEXT_DEVICES, 0, NULL, &size);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	cl_device_id *devices = (cl_device_id *) malloc(size);
	error = clGetContextInfo(context, CL_CONTEXT_DEVICES, size, devices, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	cl_device_id device = devices[0];
	error = clGetDeviceInfo(device, CL_DEVICE_NAME, sizeof(buffer), buffer, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	printf("Device: %s\n", buffer);
	
	cl_command_queue queue = clCreateCommandQueue(context, device, 0, &error);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);

	const char* source = load_kernel_source("roofline.cl");
	const size_t length = strlen(source);
	cl_program program = clCreateProgramWithSource(context, 1, &source, &length, &error);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	error = clBuildProgram(program, 1, &device, NULL, NULL, NULL);
	static char log[65536];
	memset(log, 0, sizeof(log));
	clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, sizeof(log) - 1, log, NULL);
	if (strstr(log, "warning:") || strstr(log, "error:"))
		printf("<<<<\n%s\n>>>>\n", log);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	cl_kernel kernel = clCreateKernel(program, "roofline", &error);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	size_t binarysize;
	clGetProgramInfo(program, CL_PROGRAM_BINARY_SIZES, sizeof(size_t), &binarysize, NULL);
	unsigned char *binary = (unsigned char *)malloc(binarysize);
	clGetProgramInfo(program, CL_PROGRAM_BINARIES, binarysize, &binary, NULL);
	FILE *binarydump = fopen("roofline.bin", "wb");
	fwrite(binary, 1, binarysize, binarydump);
	fclose(binarydump);
	free(binary);

	const size_t lsize = bsize;
	const size_t gsize = (GLOBAL_WORK_SIZE % bsize) ? ((GLOBAL_WORK_SIZE / bsize) * bsize + bsize) : GLOBAL_WORK_SIZE;
	float* input = (float*) malloc(sizeof(float) * GLOBAL_ARRAY_SIZE);
	float* output = (float*) malloc(sizeof(float) * gsize);
	int* indices = (int*) malloc(sizeof(int) * gsize * REPEAT_COUNT);
	for (i = 0; i < GLOBAL_ARRAY_SIZE; i++) {
		input[i] = 1.0;
	}
	for (i = 0; i < gsize; i++) {
		output[i] = 0.0;
	}
	srand(time(NULL));
	for (i = 0; i < gsize * REPEAT_COUNT; i++) {
		indices[i] = rand() % GLOBAL_ARRAY_SIZE;
	}
	cl_mem clinput = clCreateBuffer(context, CL_MEM_READ_ONLY, GLOBAL_ARRAY_SIZE * sizeof(float), NULL, &error);
	cl_mem cloutput = clCreateBuffer(context, CL_MEM_WRITE_ONLY, gsize * sizeof(float), NULL, &error);
	cl_mem clindices = clCreateBuffer(context, CL_MEM_READ_ONLY, gsize * REPEAT_COUNT * sizeof(int), NULL, &error);
	error = clEnqueueWriteBuffer(queue, clinput, CL_FALSE, 0, GLOBAL_ARRAY_SIZE * sizeof(float), input, 0, NULL, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	error = clEnqueueWriteBuffer(queue, clindices, CL_FALSE, 0, gsize * REPEAT_COUNT * sizeof(int), indices, 0, NULL, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	clSetKernelArg(kernel, 0, sizeof(clinput), &clinput);
	clSetKernelArg(kernel, 1, sizeof(cloutput), &cloutput);
	clSetKernelArg(kernel, 2, sizeof(clindices), &clindices);
	clSetKernelArg(kernel, 3, sizeof(ratio), &ratio);
	clSetKernelArg(kernel, 4, sizeof(coal), &coal);
	clSetKernelArg(kernel, 5, LOCAL_ARRAY_SIZE, NULL);
	error = clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &gsize, &lsize, 0, NULL, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	error = clEnqueueReadBuffer(queue, cloutput, CL_FALSE, 0, gsize * sizeof(float), output, 0, NULL, NULL);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);
	error = clFinish(queue);
	if (error != CL_SUCCESS)
		fatal(error, __LINE__);

	float sum = 0.0;
	for (i = 0; i < gsize; i++) {
		sum += output[i];
	}
	printf("Output: %f\n", sum);
        clReleaseContext(context);
	return 0;
}
