#!/bin/sh
#
# Wenhao Jia <jiawenhao@gmail.com>, Princeton University, 2014
# For documentation, see http://www.jiawenhao.com/hotcrp-beamer/
#
# This script saves the login cookies for later use.

echo Type in your ADMINISTRATOR login credential.
read -p "Email: " email
read -p "Password: " -s password
echo
wget --save-cookies cookies.txt --keep-session-cookies --post-data "email=$email&password=$password" $1
