#!/bin/sh
#
# Wenhao Jia <jiawenhao@gmail.com>, Princeton University, 2014
# For documentation, see http://www.jiawenhao.com/hotcrp-beamer/
#
# This script fetches every paper's specific HTML file.

mkdir -p papers
for i in $(cat id.txt); do
    [ -f papers/${i}.html ] || wget --load-cookies cookies.txt $1/paper/${i} -O papers/${i}.html
done
