#!/usr/bin/python
#
# Wenhao Jia <jiawenhao@gmail.com>, Princeton University, 2014
# For documentation, see http://www.jiawenhao.com/hotcrp-beamer/
#
# Generate from users.html a list of PC members and their submitted papers.

# List here which papers should be treated as if they are authored by certain PC members, even
# when these papers are not officially registered under these PC members' accounts.
# This could be used to handle, for example, papers registered under a PC member's secondary accounts.
# PC member names and paper IDs should be consistent with users.html and papers.html.
EXCEPTIONS = {"Shinichi Kudo": [17], "Ran Mouri": [17], "Kogoro Mouri": [38]}

# The list of the names of all PC members and PC chairs.
pcs = []
# A list of each PC member's/chair's authored papers.
papers = []

users = open("users.html")

# PC members and PC chairs are marked with (PC) or (Chair) after their names in users.html.
# Their submitted papers are listed 4 HTML lines after their names.
countdown = -1
for line in users:
    if countdown > 0:
        countdown -= 1
    if "(PC)" in line or "(Chair)" in line:
        # NOTE: This statement extracts the name of the PC member/chair.
        pc = line[line.find("ls=1") + 6 : line.find("</a>")]
        pcs.append(pc)
        # 4 HTML lines afterwards, this PC member's/chair's papers are listed.
        countdown = 4
    if countdown == 0:
        # Reset the countdown timer for the next PC member/chair.
        countdown = -1
        paper = []
        if pc in EXCEPTIONS:
            paper = EXCEPTIONS[pc]
        # NOTE: Extract the paper ID based on users.html's HTML structure.
        if "list=all" in line:
            extract = line[line.find("list=all") + 9 : line.find("\"", line.find("list=all"))]
            paper = paper + [int(p) for p in extract.split("+")]
        papers.append(sorted(paper))

# Sort PC members by their last names.
lastnames = [pc.split()[-1] for pc in pcs]
zipped = zip(lastnames, pcs, papers)
zipped.sort()
lastnames, pcs, papers = zip(*zipped)

# Write PC members and their own papers to a CSV file.
csv = open("pc.csv", 'w')
for i in range(len(pcs)):
    print pcs[i],
    csv.write(pcs[i])
    print papers[i]
    for p in papers[i]:
        csv.write(",")
        csv.write(str(p))
    csv.write("\n")
csv.close()

users.close()

print len(pcs), "PC members and", sum(len(p) for p in papers), "PC-authored papers are found."
