#!/usr/local/python
#
# Wenhao Jia <jiawenhao@gmail.com>, Princeton University, 2014
# For documentation, see http://www.jiawenhao.com/hotcrp-beamer/
#
# Generate, from papers folder, a beamer.tex beamer file.
# Each paper has two slides, one showing conflicts and the other showing paper info.

import sys
import os.path
from BeautifulSoup import BeautifulSoup
import pickle

# Hard-coded absent PC members.
absentees = ["Kisaki Eri"]
# Hard-coded discussion leaders for certain papers.
leaders = {997: "Ai Haibara", 998: "Heiji Hattori", 999: "Hiroshi Agasa"}

# Apparently Latex is a lot more limited than HTML in terms of permitted characters.
def escape(text):
    text = text.replace("&amp;", "\\&") 
    text = text.replace("?&euro;&trade;", "\'")
    text = text.replace("?&euro;&oelig;", "\"")
    text = text.replace("?&euro;", "\"")
    return text

# These papers' titles are too long to show.
skiptitles = []

# Get the list of PC members.
pc_file = open("pc.csv")
pcs = []
for line in pc_file:
    pcs.append(line.split(",")[0].strip())
print "Found", len(pcs), "PC members."
print pcs
pc_file.close()

ids = []
titles = []
revs = []
confs = []
scores = []
authors = []
# Use pickle to cache parsed arrays from previous runs.
if os.path.isfile("beamer.pickle"):
    pickled = open("beamer.pickle")
    vars = pickle.load(pickled)
    ids = vars[0]
    titles = vars[1]
    revs = vars[2]
    confs = vars[3]
    scores = vars[4]
    authors = vars[5]
    pickled.close()
else:
    # Read in the paper IDs from id.txt.
    id_file = open("id.txt")
    for line in id_file:
        ids.append(int(line))
    id_file.close()

    for id in ids:
	print "Processing paper ID " + str(id)
        paper = open("papers/" + str(id) + ".html")
        soup = BeautifulSoup(paper)

        rev = []
        score = []
        # In the table with the class name reviewers, reviewer name and scores appear on the same table row.
        table = soup.find("table", {"class": "reviewers"})
        for row in table.findAll("tr")[1 : ]:
            s = []
            # OveMer, Nov, WriQua, RevConAnd, RevRea
            for i in range(2, 7):
                t = "".join(row.contents[i].findAll(text = True)).strip()
                # Unfinished reviews simply show up as empty table cells.
                if len(t) > 0:
                    s.append(int(t))
                else:
                    s.append(0)
            # Skip empty reviews.
            if sum(s) / len(s) == 0:
                continue
            score.append(s)
            # Some reviewers use non-ASCII characters in their names.
            rev.append(row.contents[1].contents[0].strip().encode('ascii', 'replace'))
        revs.append(rev)
        scores.append(score)

        # Paper title is inside a td element with the class name pboxt.
        title = "".join(soup.find("td", {"class": "pboxt"}).findAll(text = True)).strip().encode('ascii', 'replace')
        titles.append(title)

        conf = []
        # Conflict names are in the div with the class name psv psconf on the left of each page.
        for p in soup.find("div", {"class": "psv psconf"}).findAll("p"):
            conf.append(p.string.strip().encode('ascii', 'replace'))
        confs.append(conf)

        author = []
        record = {}
        # Author names are in the p tags named odname inside the second div named papv.
        for div in soup.findAll("div", {"class": "papv"}):
            if not div.find("p", {"class": "odname"}):
                continue
            for p in div.findAll("p", {"class": "odname"}):
                # af = author & affiliation, a = author
                af = escape("".join(p.findAll(text = True)).strip().encode('ascii', 'replace'))
                if af.startswith("[blind]"):
                    af = af[8 : ]
                if "&lt;" in af:
                    af = af[ : af.find("&lt;")].strip()
                a = af
                if "(" in af:
                    a = a[ : af.find("(")].strip()
                if a not in record:
                    record[a] = af
                    author.append(af)
        authors.append(author)

        print "#" + str(id) + ": " + title
        print "Reviewers:", rev
        print "Scores:", score
        print "PC conflicts:", conf
        print "Authors:", author
        print

        paper.close()

    pickeled = open("beamer.pickle", 'w')
    pickle.dump([ids, titles, revs, confs, scores, authors], pickeled)
    pickeled.close()

# Print out the sorted list of papers with their ID and optionally their PC-authorship.
pcauthored = []
csv = open("papers.csv", 'w')
if os.path.isfile("pc.csv"):
    file = open("pc.csv")
    for line in file:
        pcauthored = pcauthored + [int(x) for x in line.split(",")[1 : ]]
    file.close()
# Put everything in a dictionary and output based on a sorted order.
print pcauthored
everything = {}
for i in range(len(ids)):
    everything[ids[i]] = [titles[i], revs[i], confs[i], scores[i]]
for pid in sorted(ids):
    csv.write(str(pid))
    csv.write(",\"")
    # Extract the title.
    csv.write(everything[pid][0])
    csv.write("\",")
    if pid in pcauthored:
        csv.write("1")
    else:
        csv.write("0")
    csv.write("\n")
csv.close()

# Print out the author list.
author_file = open("authors.csv", 'w')
for i in range(len(ids)):
    author_file.write(str(ids[i]))
    for a in authors[i]:
        author_file.write(",")
        author_file.write(a)
    author_file.write("\n")
author_file.close()

# Sort the paper list by average overall merit score.
# metric = []
# for i in range(len(scores)):
#     assert len(scores[i]) > 0
#     metric.append(float(sum(s[0] for s in scores[i])) / len(scores[i]))
# assert len(metric) == len(ids)
# assert len(metric) == len(titles)
# assert len(metric) == len(revs)
# assert len(metric) == len(confs)
# assert len(metric) == len(scores)
# zipped = zip(metric, ids, titles, revs, confs, scores)
# zipped.sort(reverse = True)
# metric, ids, titles, revs, confs, scores = zip(*zipped)

print "Start generating the beamer latex file..."
beamer = open("beamer.tex", 'w')
print >>beamer, "\\documentclass{beamer}"
print >>beamer, "\\usetheme{default}"
print >>beamer, "\\setbeamerfont{frametitle}{size=\\Large}"
print >>beamer, "\\setbeamerfont{framesubtitle}{size=\\footnotesize}"
print >>beamer, "\\usepackage{rotating}"
print >>beamer, "\\usepackage{lmodern}"
print >>beamer, "\\title{PC Meeting}"
print >>beamer, "\\date{}"
print >>beamer, "\\begin{document}\n"
# print >>beamer, "\\Large\n"

# Cover slide.
print >>beamer, "\\begin{frame}"
print >>beamer, "\\maketitle"
print >>beamer, "\\end{frame}"

for i in range(len(ids)):
    id = ids[i]
    title = escape(titles[i])
    rev = revs[i]
    conf = confs[i]
    score = scores[i]
    author = authors[i]

    print >>beamer, "\\begin{frame}\n"
    print >>beamer, "\\frametitle{" + "Conflicts on Upcoming Paper" + "}\n"
    print >>beamer, "\\Large\n"
    for j in range(len(conf)):
        c = conf[j]
        if c in rev:
            print "Paper", id, "has", c, "as both a conflict and a reviewer."
        print >>beamer, c, "\\\\"
    print >>beamer, "\n\\end{frame}\n"

    print >>beamer, "\\begin{frame}\n"
    print >>beamer, "\\frametitle{" + str(id) + ". " + title + "}\n"

    # Uncomment out the following block to display author names.
    if id not in skiptitles:
        beamer.write("\\framesubtitle{")
        beamer.write(" \\quad ".join(a.replace(" ", "~") for a in author))
        beamer.write("}\n\n")

    print >>beamer, "\\centering"
    print >>beamer, "\\small"
    print >>beamer, "\\begin{tabular}{lcccc}"

    # Find the discussion leader.
    leader = ""
    if id in leaders:
        leader = leaders[id]
    else:
        highscore = -1
        for j in range(len(rev)):
            if rev[j] in pcs and rev[j] not in absentees and rev[j] not in conf and score[j][0] > highscore:
                highscore = score[j][0]
                leader = rev[j]
    print >>beamer, "\\multicolumn{5}{l}{Discussion Lead: " + leader + "} \\\\"
    print >>beamer, "[1ex] \\hline \\\\ [-1.5ex]"

    # print >>beamer, " & Overall & Novelty & Writing & Confidence \\\\"
    # print >>beamer, " & \\rotatebox{45}{\\footnotesize Overall} & \\rotatebox{45}{\\footnotesize Novelty}" \
    #                 " & \\rotatebox{45}{\\footnotesize Writing} & \\rotatebox{45}{\\footnotesize Confidence} \\\\"
    print >>beamer, " & {\\footnotesize Overall} & {\\footnotesize Novelty}" \
                    " & {\\footnotesize Writing} & {\\footnotesize Confidence} \\\\"
    for j in range(len(rev)):
        r = rev[j]
        s = score[j]
        if r in pcs:
            beamer.write("\\textbf{")
        beamer.write(r)
        if r in pcs:
            beamer.write("}")
        # if r == leader:
            # beamer.write("$^{*}$")

        # No need to show readiness score.
        for t in s[:-1]:
            beamer.write(" & ")
            if r in pcs:
                beamer.write("\\textbf{")
            beamer.write(str(t))
            if r in pcs:
                beamer.write("}")

        print >>beamer, " \\\\"
    print >>beamer, "[1ex] \\cline{1-1} \\\\ [-1.5ex] "
    print >>beamer, "\\textbf{Bold} = PC Member \\\\"
    print >>beamer, "\\end{tabular}"
    print >>beamer, "\n\\end{frame}\n"
print >>beamer, "\\end{document}"
beamer.close()
print "All done, any warning messages should have appeared above."
