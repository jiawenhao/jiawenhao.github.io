#!/usr/bin/python
#
# Wenhao Jia <jiawenhao@gmail.com>, Princeton University, 2014
# For documentation, see http://www.jiawenhao.com/hotcrp-beamer/
#
# This script parses papers.html to generate a list of paper IDs.

# By default, the input HTML file is named papers.html.
INPUT = "papers.html"
# By deafult, the output file is named id.txt.
OUTPUT = "id.txt"
# In HotCRP v2.52, HTML lines with paper IDs have this tag keyword.
KEYWORD = 'td class="pl_id"'

input = open(INPUT, 'r')
output = open(OUTPUT, 'w')
n = 0
for line in input:
    if KEYWORD in line:
        n = n + 1
        # Extract the paper ID from <a>#ID</a> in the line.
        id = line[line.find("#") + 1 : line.find("<", line.find("#"))]
        output.write(id + "\n")
print n, "paper IDs are found."
output.close()
input.close()
